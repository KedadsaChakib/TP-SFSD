#include <stdio.h>
#include <stdlib.h>
#include "fonction.h"
#include<string.h>
#include <windows.h>
#include <ctype.h>
#include <conio.h>
 TEnreg new_enreg ;
 TEnrindex new_enreg_index ;
 int nblire=0 , nbecrire=0 ;
TOF fx ;
TOF * fich_index = &fx ;
LNOF fichier ;
LNOF * mon_fich = &fichier;
LNOF fichier1 ;
LNOF * mon_fich1 = &fichier1;
LNOF fichier2 ;
LNOF * mon_fich2 = &fichier2;
LNOF fichier3 ;
LNOF * mon_fich3 = &fichier3;
LNOF fichier4 ;
LNOF * mon_fich4 = &fichier4;
LNOF fichier5 ;
LNOF * mon_fich5 = &fichier5;
LNOF fichier6 ;
LNOF * mon_fich6 = &fichier6;
TBloc buff ;
int nbenreg ;
char nom_fich[30]="PERSONNEL-ANP_DZ.bin";


 int main()
{
    TableIndex * Tableau = calloc(1,sizeof(TableIndex));
    TableIndex * Tab =calloc(1,sizeof(TableIndex));
int choice=0;
while(choice!=8)
{
 Clear_screen();
 Image_te3_Esi_tclignioti();
 printf("\n\n");
 Animation_tank(1);
 textcolor(WHITE);
 menu_principal();
 printf("\n\n Enter Your CHOICE: ");
 scanf("%d",&choice);
 switch(choice)
 {
  case 1:     printf("\n Donnez le nombre de enregs a creer:");
              scanf("%d",&nbenreg);
              creation_du_fichier(mon_fich,nom_fich,nbenreg,Tableau,&nblire,&nbecrire);
              printf("\nLe fichier PERSONNEL-ANP_DZ.bin a ete cree avec succes");
              printf("\nLe fichier d'INDEX a ete cree avec succes");
              affichage_entete(mon_fich,nom_fich);
              printf("\n Voulez vous afficher le fichier ?");

              int choice1 = 0;
              while(choice1!= 1 && choice1!= 2 ){
                    printf("\n\tChoisissez une opertation");
                    printf("\n\t\t 1. OUI");
                    printf("\n\t\t 2. NON\n");
                    scanf("%d",&choice1);
                    int n = 0;
                    switch(choice1){
                    case 1 :
                        printf("\nCombien de bloc voulez vous afficher ?\n");
                        scanf("%d",&n);
                        Affichage_N_premier_bloc(mon_fich,nom_fich,n);
                                break;
                    case 2 :    break;
                    default : printf("\nChoix invalide");
                                break;
                    }
              }
              break;

  case 2:

  printf("\n le nom : ");
  char name[30],prenom[30];
  scanf("%s",name);
  printf("\n name is %s", name);
  strcpy(new_enreg.nom  ,   name);
  printf("\n le prenome : ");
  scanf("%s",prenom);
  strcpy(new_enreg.prenom, prenom);
  printf("\n le matricule: ");
  scanf("%d",&new_enreg.matricule);
  printf(" le matrciule de enr.mat= %d",new_enreg.matricule);
     new_enreg.grade = 1;
     new_enreg.groupe_sang = 1 ;
     new_enreg.region_melit =  2 ;
     new_enreg.wilaya_nais = 5 ;
     new_enreg.efface = 0 ;
     new_enreg.date_de_nais[0] = 1995 ;
     new_enreg.date_de_nais[1] = 5 ;
     new_enreg.date_de_nais[2] = 26 ;
     int blclof , deplof ;
     insertion_LNOF(mon_fich,nom_fich,&new_enreg,&blclof,&deplof);
     nblire++;
     nbecrire++;
     printf("\n blclof=%d \t deplof=%d",blclof,deplof);
      new_enreg_index.efface = 0 ;
      new_enreg_index.matricule = new_enreg.matricule;
      new_enreg_index.num_bloc = blclof;
      new_enreg_index.pos_bloc = deplof ;

      ouvrir_index(fich_index,"Fichier_Index_officiel.bin",'a');

     insertion_TOF(fich_index,new_enreg_index,&nblire,&nbecrire);
     fermer_index(fich_index);

              break;
  case 3:
              printf("\nYOU SELECTED OPTION 3\n");
              modif_reg_melit(mon_fich,fich_index,nom_fich,"Fichier_Index_officiel.bin",&nblire,&nbecrire);

              break;
  case 4:
              printf("\nYOU SELECTED OPTION 4\n");

              suprim_enreg(mon_fich,fich_index,nom_fich,"Fichier_Index_officiel.bin");

              break;
  case 5:
              printf("\nYOU SELECTED OPTION 5\n");
              sup_selon_force(mon_fich,nom_fich,fich_index,"Fichier_Index_officiel.bin",&nblire,&nbecrire);
              break;
  case 6:
              printf("\nDonnez la plage d'age a recherche\n");
              int min =0, max=0;
              printf("Entre :");
              scanf("%d",&min);
              printf("et :");
              scanf("%d",&max);
              printf("\nDonnez le numero de la region que vous voulez affiche\n");
              int Nb = 0;
              scanf("%d",&Nb);
              Affichage_selon_region_age(mon_fich,nom_fich,min,max,Nb,&nblire,&nbecrire);
              printf("\n nblire=%d \n nbecrire=%d \n",nblire,nbecrire);

              break;
  case 7:
              printf("\nVeuillez entrer la categorie de grade a afficher\n");
              menu_grade();
              Nb=0;
              scanf("%d",&Nb);
              Affichage_selon_grade(mon_fich,nom_fich,Nb);
              break;
  case 8:
              Fragmentation(mon_fich,nom_fich,mon_fich1,mon_fich2,mon_fich3,mon_fich4,mon_fich5,mon_fich6);
              break;

  case 9:
              printf("\nYOU SELECTED OPTION 8");
              exit(0);
  otherwise:
             printf("\nINVALID SELECTION...Please try again");
  }
  getch();
}

   return 0;


}




























  // buff.NbEnreg = 5;
   // buff.t[0].efface = 55 ;
  // ouvrir(mon_fich,nom_fich,'a');
  // ecrire_dire(mon_fich,1,&buff);
   //  buff.suiv= 45;

    //ecrire_dire(mon_fich,2,&buff);
    // buff.suiv= 106;
   // lire_dire(mon_fich,2,&buff);
   // printf(" \n la valeur de buff.suiv est %d", buff.suiv);
 //   buff.suiv= 45;
  /* printf(" le fichier de ilyes contient rien ");

   printf(" \n the random number is  %d " , random_number_between_two_bornes(10000,50000) );

    TEnreg temp ;
    gen_matricule(&temp);
    gen_nom(&temp);
    gen_prenom(&temp);
    gen_g_sang(&temp);
    gen_reg_melit(&temp);
    printf(" \n la matricule du temp est %d \n le nom genere est %s sa prenom  est %s \n son sang est %d \n son reg meli set %d", temp.matricule , temp.nom , temp.prenom , temp.groupe_sang , temp.region_melit);*//*/
///essaaayy *******************/




 /* size of a file :
   fseek ( mon_fich->f , 0, SEEK_END ); /* on se place �  0 octets de la fin du fichier (SEEK_END)
  int   longueur_fichier = ftell (mon_fich->f);
    printf(" size of this struct is %d \n ",longueur_fichier);
    */
/*
///************ fonction affichage *************/
/* ouvrir(mon_fich,nom_fich,'a');
  TBloc buffafichage;
  lire_dire(mon_fich,85,&buffafichage);
/*
   /*    int k  ;
       for( k=50; k<= 60 ; k++)
{
      printf(" le nom du enreg %d est : %s \n", k, buffafichage.t[k].nom);
      printf(" est efface ? %d ", buffafichage.t[k].efface);
      printf(" le wilaya du enreg %d est : %d \n" , k , buffafichage.t[k].wilaya_nais);
      printf(" le blocc affichage.suiv est %d et le nb de enreg est %d", buffafichage.suiv,buffafichage.NbEnreg);
}
///*************** fin fonction de affichage****************/
/*
   TBloc buffafichage;
   lire_dire(mon_fich,86,&buffafichage);

       int k  ;
       for( k=40; k<= 50 ; k++)
{     // if (buffafichage.t[k].efface == 0){
      printf(" le nom du enreg %d est : %s \n", k, buffafichage.t[k].nom);
      printf(" est efface ? %d ", buffafichage.t[k].efface);
      printf(" le wilaya du enreg %d est : %d \n" , k , buffafichage.t[k].wilaya_nais);
      printf(" le blocc affichage.suiv est %d et le nb de enreg est %d", buffafichage.suiv,buffafichage.NbEnreg);// }
}
///*************** fin fonction de affichage****************/

/*affichage_entete(mon_fich,nom_fich);
TEnreg ess;
//  novo.matricule=055;
 // strcpy(novo.nom,"ilyes");
  printf(" le nom ");
  hicham.matricule= 1450 ;
  hicham.grade = 5 ;
  //hicham.groupe_sang= 1;
 /* ess.matricule = 777;
  ess.grade = 1;
   printf(" ess.grade est %d avant la modif \n", ess.grade);
  printf(" ess.matricul est %d avant la modif \n", ess.matricule);
  ess = hicham;
  printf(" ess/hich.matricul est %d apres la modif", ess.matricule);
   printf(" ess.grade est %d apres la modif \n", ess.grade);

// haha yuhan ;
 yuhan.call = 140 ;
 printf(" uhan.call est %d", yuhan.call);

TEnreg nvenreg ;
nvenreg.force_arme = 1 ;
nvenreg.region_melit = 4 ;


*/
int mainn()
{ /** DISCLAIMER : THIS IS JUST A TEMPLATE FOR YOU BCH TZRB TKMLHA
    SO IT IS **** UGLY *** AND DOESNT REFLECT MY ARTISTIC TALENTS (if i have any ) **/

    // animation of the tank
    Clear_screen() ;
    for(int j=0;j<2;j++)
    {
       for(int i=0;i<=4;i++)
        {
          Animation_tank(j) ;
          usleep(500000);
          system("cls");
        }
    }
    printf("\n press something ") ;
    getch() ; // lazm tapi fel keyboard bch tkhrj



    // animation te3 esi
     for(int num=0;num<18;num++) // le nombre de p�riodes
    {
      Image_te3_Esi_tclignioti(num);
      usleep(100000);
      system("cls");
    }


}

///*****************************************************************************
